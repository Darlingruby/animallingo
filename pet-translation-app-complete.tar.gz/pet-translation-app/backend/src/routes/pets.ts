import { FastifyInstance, FastifyPluginOptions } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Validation schemas
const createPetSchema = z.object({
  name: z.string().min(1).max(100),
  species: z.enum(['dog', 'cat', 'bird', 'rabbit', 'hamster', 'other']),
  breed: z.string().max(100).optional().nullable(),
  birthDate: z.string().datetime().optional().nullable(),
  gender: z.enum(['male', 'female', 'unknown']).optional().nullable(),
  avatarUrl: z.string().url().optional().nullable(),
  weight: z.number().positive().optional().nullable(),
  weightUnit: z.enum(['kg', 'lbs']).default('kg'),
  personality: z.array(z.string()).default([]),
  favoriteThings: z.array(z.string()).default([]),
  dislikes: z.array(z.string()).default([]),
  medicalNotes: z.string().max(1000).optional().nullable(),
  vocabularyLevel: z.number().int().min(1).max(5).default(1),
  translationStyle: z.enum(['casual', 'formal', 'playful', 'direct']).default('casual')
});

const updatePetSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  species: z.enum(['dog', 'cat', 'bird', 'rabbit', 'hamster', 'other']).optional(),
  breed: z.string().max(100).optional().nullable(),
  birthDate: z.string().datetime().optional().nullable(),
  gender: z.enum(['male', 'female', 'unknown']).optional().nullable(),
  avatarUrl: z.string().url().optional().nullable(),
  weight: z.number().positive().optional().nullable(),
  weightUnit: z.enum(['kg', 'lbs']).optional(),
  personality: z.array(z.string()).optional(),
  favoriteThings: z.array(z.string()).optional(),
  dislikes: z.array(z.string()).optional(),
  medicalNotes: z.string().max(1000).optional().nullable(),
  vocabularyLevel: z.number().int().min(1).max(5).optional(),
  translationStyle: z.enum(['casual', 'formal', 'playful', 'direct']).optional()
});

const petResponseSchema = z.object({
  id: z.string(),
  name: z.string(),
  species: z.string(),
  breed: z.string().nullable(),
  birthDate: z.string().nullable(),
  gender: z.string().nullable(),
  avatarUrl: z.string().nullable(),
  weight: z.number().nullable(),
  weightUnit: z.string(),
  personality: z.array(z.string()),
  favoriteThings: z.array(z.string()),
  dislikes: z.array(z.string()),
  medicalNotes: z.string().nullable(),
  vocabularyLevel: z.number(),
  translationStyle: z.string(),
  createdAt: z.string(),
  updatedAt: z.string(),
  ownerId: z.string()
});

export async function petRoutes(
  app: FastifyInstance,
  options: FastifyPluginOptions
) {
  const server = app.withTypeProvider<ZodTypeProvider>();

  // List all pets for current user
  server.get('/', {
    onRequest: [authenticate],
    schema: {
      tags: ['Pets'],
      summary: 'List all pets for current user',
      security: [{ bearerAuth: [] }],
      response: {
        200: z.object({
          success: z.literal(true),
          data: z.object({
            pets: z.array(petResponseSchema)
          })
        })
      }
    }
  }, async (request, reply) => {
    const userId = (request as any).user.userId;

    const pets = await prisma.pet.findMany({
      where: { ownerId: userId },
      orderBy: { createdAt: 'desc' }
    });

    return reply.send({
      success: true,
      data: {
        pets: pets.map(pet => ({
          ...pet,
          personality: JSON.parse(pet.personality || '[]'),
          favoriteThings: JSON.parse(pet.favoriteThings || '[]'),
          dislikes: JSON.parse(pet.dislikes || '[]'),
          birthDate: pet.birthDate?.toISOString() || null,
          createdAt: pet.createdAt.toISOString(),
          updatedAt: pet.updatedAt.toISOString()
        }))
      }
    });
  });

  // Get single pet
  server.get('/:id', {
    onRequest: [authenticate],
    schema: {
      tags: ['Pets'],
      summary: 'Get pet by ID',
      security: [{ bearerAuth: [] }],
      params: z.object({ id: z.string().uuid() }),
      response: {
        200: z.object({
          success: z.literal(true),
          data: z.object({ pet: petResponseSchema })
        }),
        404: z.object({
          success: z.literal(false),
          error: z.object({ code: z.number(), message: z.string() })
        })
      }
    }
  }, async (request, reply) => {
    const userId = (request as any).user.userId;
    const { id } = request.params;

    const pet = await prisma.pet.findFirst({
      where: { id, ownerId: userId }
    });

    if (!pet) {
      return reply.status(404).send({
        success: false,
        error: { code: 404, message: 'Pet not found' }
      });
    }

    return reply.send({
      success: true,
      data: {
        pet: {
          ...pet,
          personality: JSON.parse(pet.personality || '[]'),
          favoriteThings: JSON.parse(pet.favoriteThings || '[]'),
          dislikes: JSON.parse(pet.dislikes || '[]'),
          birthDate: pet.birthDate?.toISOString() || null,
          createdAt: pet.createdAt.toISOString(),
          updatedAt: pet.updatedAt.toISOString()
        }
      }
    });
  });

  // Create pet
  server.post('/', {
    onRequest: [authenticate],
    schema: {
      tags: ['Pets'],
      summary: 'Create a new pet',
      security: [{ bearerAuth: [] }],
      body: createPetSchema,
      response: {
        201: z.object({
          success: z.literal(true),
          data: z.object({ pet: petResponseSchema })
        })
      }
    }
  }, async (request, reply) => {
    const userId = (request as any).user.userId;
    const data = request.body;

    const pet = await prisma.pet.create({
      data: {
        name: data.name,
        species: data.species,
        breed: data.breed,
        birthDate: data.birthDate ? new Date(data.birthDate) : null,
        gender: data.gender,
        avatarUrl: data.avatarUrl,
        weight: data.weight,
        weightUnit: data.weightUnit,
        personality: JSON.stringify(data.personality),
        favoriteThings: JSON.stringify(data.favoriteThings),
        dislikes: JSON.stringify(data.dislikes),
        medicalNotes: data.medicalNotes,
        vocabularyLevel: data.vocabularyLevel,
        translationStyle: data.translationStyle,
        ownerId: userId
      }
    });

    return reply.status(201).send({
      success: true,
      data: {
        pet: {
          ...pet,
          personality: JSON.parse(pet.personality || '[]'),
          favoriteThings: JSON.parse(pet.favoriteThings || '[]'),
          dislikes: JSON.parse(pet.dislikes || '[]'),
          birthDate: pet.birthDate?.toISOString() || null,
          createdAt: pet.createdAt.toISOString(),
          updatedAt: pet.updatedAt.toISOString()
        }
      }
    });
  });

  // Update pet
  server.patch('/:id', {
    onRequest: [authenticate],
    schema: {
      tags: ['Pets'],
      summary: 'Update pet information',
      security: [{ bearerAuth: [] }],
      params: z.object({ id: z.string().uuid() }),
      body: updatePetSchema,
      response: {
        200: z.object({
          success: z.literal(true),
          data: z.object({ pet: petResponseSchema })
        }),
        404: z.object({
          success: z.literal(false),
          error: z.object({ code: z.number(), message: z.string() })
        })
      }
    }
  }, async (request, reply) => {
    const userId = (request as any).user.userId;
    const { id } = request.params;
    const data = request.body;

    // Check ownership
    const existingPet = await prisma.pet.findFirst({
      where: { id, ownerId: userId }
    });

    if (!existingPet) {
      return reply.status(404).send({
        success: false,
        error: { code: 404, message: 'Pet not found' }
      });
    }

    // Build update data
    const updateData: any = { ...data };
    if (data.birthDate !== undefined) {
      updateData.birthDate = data.birthDate ? new Date(data.birthDate) : null;
    }
    if (data.personality !== undefined) {
      updateData.personality = JSON.stringify(data.personality);
    }
    if (data.favoriteThings !== undefined) {
      updateData.favoriteThings = JSON.stringify(data.favoriteThings);
    }
    if (data.dislikes !== undefined) {
      updateData.dislikes = JSON.stringify(data.dislikes);
    }

    const pet = await prisma.pet.update({
      where: { id },
      data: updateData
    });

    return reply.send({
      success: true,
      data: {
        pet: {
          ...pet,
          personality: JSON.parse(pet.personality || '[]'),
          favoriteThings: JSON.parse(pet.favoriteThings || '[]'),
          dislikes: JSON.parse(pet.dislikes || '[]'),
          birthDate: pet.birthDate?.toISOString() || null,
          createdAt: pet.createdAt.toISOString(),
          updatedAt: pet.updatedAt.toISOString()
        }
      }
    });
  });

  // Delete pet
  server.delete('/:id', {
    onRequest: [authenticate],
    schema: {
      tags: ['Pets'],
      summary: 'Delete a pet',
      security: [{ bearerAuth: [] }],
      params: z.object({ id: z.string().uuid() }),
      response: {
        200: z.object({
          success: z.literal(true),
          data: z.object({ message: z.string() })
        }),
        404: z.object({
          success: z.literal(false),
          error: z.object({ code: z.number(), message: z.string() })
        })
      }
    }
  }, async (request, reply) => {
    const userId = (request as any).user.userId;
    const { id } = request.params;

    // Check ownership
    const existingPet = await prisma.pet.findFirst({
      where: { id, ownerId: userId }
    });

    if (!existingPet) {
      return reply.status(404).send({
        success: false,
        error: { code: 404, message: 'Pet not found' }
      });
    }

    await prisma.pet.delete({ where: { id } });

    return reply.send({
      success: true,
      data: { message: 'Pet deleted successfully' }
    });
  });

  // Get pet stats
  server.get('/:id/stats', {
    onRequest: [authenticate],
    schema: {
      tags: ['Pets'],
      summary: 'Get pet translation statistics',
      security: [{ bearerAuth: [] }],
      params: z.object({ id: z.string().uuid() }),
      response: {
        200: z.object({
          success: z.literal(true),
          data: z.object({
            stats: z.object({
              totalTranslations: z.number(),
              favoriteTranslations: z.number(),
              topEmotions: z.array(z.object({ emotion: z.string(), count: z.number() })),
              topSignalTypes: z.array(z.object({ type: z.string(), count: z.number() })),
              averageConfidence: z.number()
            })
          })
        })
      }
    }
  }, async (request, reply) => {
    const userId = (request as any).user.userId;
    const { id } = request.params;

    // Verify ownership
    const pet = await prisma.pet.findFirst({
      where: { id, ownerId: userId }
    });

    if (!pet) {
      return reply.status(404).send({
        success: false,
        error: { code: 404, message: 'Pet not found' }
      });
    }

    const stats = await getPetStats(id);

    return reply.send({
      success: true,
      data: { stats }
    });
  });
}

// Helper function to get pet stats
async function getPetStats(petId: string) {
  const [
    totalTranslations,
    favoriteTranslations,
    emotionCounts,
    signalTypeCounts,
    avgConfidence
  ] = await Promise.all([
    prisma.translation.count({ where: { petId } }),
    prisma.translation.count({ where: { petId, isFavorite: true } }),
    prisma.translation.groupBy({
      by: ['emotionDetected'],
      where: { petId, emotionDetected: { not: null } },
      _count: { emotionDetected: true },
      orderBy: { _count: { emotionDetected: 'desc' } },
      take: 5
    }),
    prisma.translation.groupBy({
      by: ['signalType'],
      where: { petId, signalType: { not: null } },
      _count: { signalType: true },
      orderBy: { _count: { signalType: 'desc' } },
      take: 5
    }),
    prisma.translation.aggregate({
      where: { petId, confidence: { not: null } },
      _avg: { confidence: true }
    })
  ]);

  return {
    totalTranslations,
    favoriteTranslations,
    topEmotions: emotionCounts.map(e => ({
      emotion: e.emotionDetected!,
      count: e._count.emotionDetected
    })),
    topSignalTypes: signalTypeCounts.map(s => ({
      type: s.signalType!,
      count: s._count.signalType
    })),
    averageConfidence: avgConfidence._avg.confidence || 0
  };
}

// Authentication middleware
async function authenticate(request: any, reply: any) {
  try {
    await request.jwtVerify();
  } catch (err) {
    reply.status(401).send({
      success: false,
      error: { code: 401, message: 'Unauthorized' }
    });
  }
}
