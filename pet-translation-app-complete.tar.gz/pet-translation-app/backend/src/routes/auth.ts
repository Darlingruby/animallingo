import { FastifyInstance, FastifyPluginOptions, FastifyRequest, FastifyReply } from 'fastify';
import { ZodTypeProvider } from 'fastify-type-provider-zod';
import { z } from 'zod';
import bcrypt from 'bcrypt';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// Validation schemas
const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(100),
  name: z.string().min(1).max(100).optional()
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string()
});

const refreshSchema = z.object({
  refreshToken: z.string()
});

const updateProfileSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  avatarUrl: z.string().url().optional().nullable()
});

const changePasswordSchema = z.object({
  currentPassword: z.string(),
  newPassword: z.string().min(8).max(100)
});

export async function authRoutes(
  app: FastifyInstance,
  options: FastifyPluginOptions
) {
  const server = app.withTypeProvider<ZodTypeProvider>();

  // Register
  server.post('/register', {
    schema: {
      tags: ['Authentication'],
      summary: 'Register a new user',
      body: registerSchema,
      response: {
        201: z.object({
          success: z.literal(true),
          data: z.object({
            user: z.object({
              id: z.string(),
              email: z.string(),
              name: z.string().nullable(),
              createdAt: z.string()
            }),
            token: z.string()
          })
        }),
        400: z.object({
          success: z.literal(false),
          error: z.object({ code: z.number(), message: z.string() })
        }),
        409: z.object({
          success: z.literal(false),
          error: z.object({ code: z.number(), message: z.string() })
        })
      }
    }
  }, async (request, reply) => {
    const { email, password, name } = request.body;

    // Check if user exists
    const existingUser = await prisma.user.findUnique({
      where: { email }
    });

    if (existingUser) {
      return reply.status(409).send({
        success: false,
        error: { code: 409, message: 'Email already registered' }
      });
    }

    // Hash password
    const passwordHash = await bcrypt.hash(password, 12);

    // Create user
    const user = await prisma.user.create({
      data: {
        email,
        passwordHash,
        name
      },
      select: {
        id: true,
        email: true,
        name: true,
        createdAt: true
      }
    });

    // Generate JWT
    const token = app.jwt.sign({ 
      userId: user.id,
      email: user.email 
    });

    return reply.status(201).send({
      success: true,
      data: {
        user: {
          ...user,
          createdAt: user.createdAt.toISOString()
        },
        token
      }
    });
  });

  // Login
  server.post('/login', {
    schema: {
      tags: ['Authentication'],
      summary: 'Login user',
      body: loginSchema,
      response: {
        200: z.object({
          success: z.literal(true),
          data: z.object({
            user: z.object({
              id: z.string(),
              email: z.string(),
              name: z.string().nullable()
            }),
            token: z.string()
          })
        }),
        401: z.object({
          success: z.literal(false),
          error: z.object({ code: z.number(), message: z.string() })
        })
      }
    }
  }, async (request, reply) => {
    const { email, password } = request.body;

    // Find user
    const user = await prisma.user.findUnique({
      where: { email }
    });

    if (!user || !user.isActive) {
      return reply.status(401).send({
        success: false,
        error: { code: 401, message: 'Invalid credentials' }
      });
    }

    // Verify password
    const isValid = await bcrypt.compare(password, user.passwordHash);

    if (!isValid) {
      return reply.status(401).send({
        success: false,
        error: { code: 401, message: 'Invalid credentials' }
      });
    }

    // Update last login
    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() }
    });

    // Generate JWT
    const token = app.jwt.sign({ 
      userId: user.id,
      email: user.email 
    });

    return reply.send({
      success: true,
      data: {
        user: {
          id: user.id,
          email: user.email,
          name: user.name
        },
        token
      }
    });
  });

  // Get current user
  server.get('/me', {
    onRequest: [authenticate],
    schema: {
      tags: ['Authentication'],
      summary: 'Get current user profile',
      security: [{ bearerAuth: [] }],
      response: {
        200: z.object({
          success: z.literal(true),
          data: z.object({
            user: z.object({
              id: z.string(),
              email: z.string(),
              name: z.string().nullable(),
              avatarUrl: z.string().nullable(),
              createdAt: z.string(),
              lastLoginAt: z.string().nullable()
            })
          })
        })
      }
    }
  }, async (request, reply) => {
    const userId = (request as any).user.userId;

    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        avatarUrl: true,
        createdAt: true,
        lastLoginAt: true
      }
    });

    if (!user) {
      return reply.status(404).send({
        success: false,
        error: { code: 404, message: 'User not found' }
      });
    }

    return reply.send({
      success: true,
      data: {
        user: {
          ...user,
          createdAt: user.createdAt.toISOString(),
          lastLoginAt: user.lastLoginAt?.toISOString() || null
        }
      }
    });
  });

  // Update profile
  server.patch('/me', {
    onRequest: [authenticate],
    schema: {
      tags: ['Authentication'],
      summary: 'Update user profile',
      security: [{ bearerAuth: [] }],
      body: updateProfileSchema,
      response: {
        200: z.object({
          success: z.literal(true),
          data: z.object({
            user: z.object({
              id: z.string(),
              email: z.string(),
              name: z.string().nullable(),
              avatarUrl: z.string().nullable()
            })
          })
        })
      }
    }
  }, async (request, reply) => {
    const userId = (request as any).user.userId;
    const updateData = request.body;

    const user = await prisma.user.update({
      where: { id: userId },
      data: updateData,
      select: {
        id: true,
        email: true,
        name: true,
        avatarUrl: true
      }
    });

    return reply.send({
      success: true,
      data: { user }
    });
  });

  // Change password
  server.post('/change-password', {
    onRequest: [authenticate],
    schema: {
      tags: ['Authentication'],
      summary: 'Change password',
      security: [{ bearerAuth: [] }],
      body: changePasswordSchema,
      response: {
        200: z.object({
          success: z.literal(true),
          data: z.object({ message: z.string() })
        }),
        400: z.object({
          success: z.literal(false),
          error: z.object({ code: z.number(), message: z.string() })
        })
      }
    }
  }, async (request, reply) => {
    const userId = (request as any).user.userId;
    const { currentPassword, newPassword } = request.body;

    const user = await prisma.user.findUnique({
      where: { id: userId }
    });

    if (!user) {
      return reply.status(404).send({
        success: false,
        error: { code: 404, message: 'User not found' }
      });
    }

    // Verify current password
    const isValid = await bcrypt.compare(currentPassword, user.passwordHash);
    if (!isValid) {
      return reply.status(400).send({
        success: false,
        error: { code: 400, message: 'Current password is incorrect' }
      });
    }

    // Hash new password
    const newPasswordHash = await bcrypt.hash(newPassword, 12);

    await prisma.user.update({
      where: { id: userId },
      data: { passwordHash: newPasswordHash }
    });

    return reply.send({
      success: true,
      data: { message: 'Password updated successfully' }
    });
  });

  // Logout (client-side token removal, but we can track it if needed)
  server.post('/logout', {
    onRequest: [authenticate],
    schema: {
      tags: ['Authentication'],
      summary: 'Logout user',
      security: [{ bearerAuth: [] }],
      response: {
        200: z.object({
          success: z.literal(true),
          data: z.object({ message: z.string() })
        })
      }
    }
  }, async (request, reply) => {
    // In a stateless JWT setup, logout is handled client-side
    // Optionally, we could add token to a blacklist here
    return reply.send({
      success: true,
      data: { message: 'Logged out successfully' }
    });
  });
}

// Authentication middleware
async function authenticate(request: FastifyRequest, reply: FastifyReply) {
  try {
    await request.jwtVerify();
  } catch (err) {
    reply.status(401).send({
      success: false,
      error: { code: 401, message: 'Unauthorized' }
    });
  }
}
